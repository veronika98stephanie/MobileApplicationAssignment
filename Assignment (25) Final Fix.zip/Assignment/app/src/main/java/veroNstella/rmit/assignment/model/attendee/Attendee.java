package veroNstella.rmit.assignment.model.attendee;

public interface Attendee {
    String getAttendeesId();

    String getName();

    void setName(String name);
}