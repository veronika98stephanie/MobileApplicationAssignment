package veroNstella.rmit.assignment.exception;

public class InvalidDateException extends Exception {
    public InvalidDateException(String message) {
        super(message);
    }
}
