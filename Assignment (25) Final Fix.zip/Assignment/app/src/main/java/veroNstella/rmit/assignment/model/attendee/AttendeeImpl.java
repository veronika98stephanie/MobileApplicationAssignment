package veroNstella.rmit.assignment.model.attendee;

public class AttendeeImpl extends AttendeeAbstract {

    public AttendeeImpl(String attendeesId, String name) {
        super(attendeesId, name);
    }
}
