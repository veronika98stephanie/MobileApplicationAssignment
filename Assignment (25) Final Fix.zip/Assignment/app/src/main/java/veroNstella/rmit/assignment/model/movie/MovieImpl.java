package veroNstella.rmit.assignment.model.movie;

public class MovieImpl extends MovieAbstract {
    public MovieImpl(String movieId, String title, int year, String poster) {
        super(movieId, title, year, poster);
    }
}